package com.example.congressionalappchallenge;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.congressionalappchallenge.databinding.FragmentThirdBinding;

public class ThirdFragment extends Fragment {



    private FragmentThirdBinding binding;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState

    ) {

        binding = FragmentThirdBinding.inflate(inflater, container, false);


        return binding.getRoot();

    }


    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        EditText heightTxt = (EditText) getView().findViewById(R.id.editTextNumber);
        EditText weightTxt = (EditText) getView().findViewById(R.id.editTextNumber2);
        TextView textView = (TextView) getView().findViewById(R.id.textView6);
        binding.SubmitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    int height = Integer.parseInt(heightTxt.getText().toString());
                    int weight = Integer.parseInt(weightTxt.getText().toString());

                    double bMI = (((double) weight / (height * height))*703) + .5;

                    String bmi = "na";

                    if(bMI < 18.5){
                        bmi = "Underweight - BMI: " + (int)bMI;
                    }
                    else if(bMI < 25){
                        bmi = "Normal - BMI: " + (int)bMI;
                    }
                    else if(bMI < 40){
                        bmi = "Overweight - BMI: " + (int)bMI;
                    }
                    else{
                        bmi = "Obese - BMI: " + (int)bMI;
                    }



                   textView.setText(bmi);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}